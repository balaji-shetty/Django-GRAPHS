from django.contrib import admin

from main.models import Student,Attendence


class StudentAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'language', 'grades', 'gender','location')
    list_filter = ('language', 'gender', 'grades','location')
    save_as = True
    save_on_top = True
    # change_list_template = 'change_list_graph.html'


admin.site.register(Student, StudentAdmin)



class AttendenceAdmin(admin.ModelAdmin):
    list_display = ('Student','subject','gender1','location1','language1')
    list_filter = ('Student','subject','gender1','location1','language1')
    save_as = True
    save_on_top = True
    change_list_template = 'change_list_graph1.html'


admin.site.register(Attendence,AttendenceAdmin)

